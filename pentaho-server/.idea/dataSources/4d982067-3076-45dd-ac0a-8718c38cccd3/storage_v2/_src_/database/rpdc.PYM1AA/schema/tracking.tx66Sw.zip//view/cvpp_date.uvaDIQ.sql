create view cvpp_date as
SELECT cvpp.report_date
FROM tracking.cvpp
GROUP BY cvpp.report_date;

