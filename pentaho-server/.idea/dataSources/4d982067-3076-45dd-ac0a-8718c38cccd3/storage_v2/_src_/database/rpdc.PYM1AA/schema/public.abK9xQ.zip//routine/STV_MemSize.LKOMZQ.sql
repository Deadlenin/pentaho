create function STV_MemSize as
    language 'C++'
    name 'IntNOStrFactory' library public.PlaceLib;

