create aggregate function ApproxCountDistinctSynopsis13 as
    language 'C++'
    name 'ApproxCountDistinctSynopsis13Factory' library public.ApproximateLib;

