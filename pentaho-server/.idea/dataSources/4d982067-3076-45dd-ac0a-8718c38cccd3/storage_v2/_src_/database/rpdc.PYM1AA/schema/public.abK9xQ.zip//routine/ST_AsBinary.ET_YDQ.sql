create function ST_AsBinary as
    language 'C++'
    name 'AsBinaryGeoFactory' library public.PlaceLib;

