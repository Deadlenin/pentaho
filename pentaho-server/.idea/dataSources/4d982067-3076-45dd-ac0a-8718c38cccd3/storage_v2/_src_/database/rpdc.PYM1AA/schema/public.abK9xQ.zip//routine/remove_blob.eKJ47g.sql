create transform function remove_blob as
    language 'C++'
    name 'RemoveBlobFactory' library public.MachineLearningLib;

