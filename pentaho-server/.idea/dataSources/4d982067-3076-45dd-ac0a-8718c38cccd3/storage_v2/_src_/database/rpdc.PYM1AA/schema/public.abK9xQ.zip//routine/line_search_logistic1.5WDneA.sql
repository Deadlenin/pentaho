create transform function line_search_logistic1 as
    language 'C++'
    name 'LineSearchLogistic1Factory' library public.MachineLearningLib;

