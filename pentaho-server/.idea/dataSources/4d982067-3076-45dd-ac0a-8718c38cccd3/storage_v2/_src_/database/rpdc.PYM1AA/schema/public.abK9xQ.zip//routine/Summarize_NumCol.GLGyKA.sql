create transform function Summarize_NumCol as
    language 'C++'
    name 'NumericalSummarizerFactory' library public.MachineLearningLib;

