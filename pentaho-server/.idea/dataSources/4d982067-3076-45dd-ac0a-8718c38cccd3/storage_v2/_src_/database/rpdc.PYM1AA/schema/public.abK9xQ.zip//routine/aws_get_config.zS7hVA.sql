create function aws_get_config as
    language 'C++'
    name 'AwsGetConfigFactory' library public.awslib;

