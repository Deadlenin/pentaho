create transform function reg_final_bfgs as
    language 'C++'
    name 'RegFinalBFGSFactory' library public.MachineLearningLib;

