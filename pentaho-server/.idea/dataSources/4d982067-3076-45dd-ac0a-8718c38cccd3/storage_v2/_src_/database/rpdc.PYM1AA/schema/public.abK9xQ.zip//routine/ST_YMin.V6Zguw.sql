create function ST_YMin as
    language 'C++'
    name 'YMinGeoFactory' library public.PlaceLib;

