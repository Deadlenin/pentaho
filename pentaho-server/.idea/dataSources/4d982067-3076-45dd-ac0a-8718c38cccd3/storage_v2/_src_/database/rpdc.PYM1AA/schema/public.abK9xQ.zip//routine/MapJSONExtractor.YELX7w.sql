create function MapJSONExtractor as
    language 'C++'
    name 'FJSONExtractorFactory' library public.FlexTableLib;

