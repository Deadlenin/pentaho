create function isOrContains(map Long Varchar, val Varchar) return Boolean as
begin
    RETURN CASE WHEN (public.MapSize(map) <> (-1)) THEN public.MapContainsValue(map, val) ELSE (map = (val)) END;
end;

