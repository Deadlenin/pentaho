create function STV_DWithin as
    language 'C++'
    name 'DWithinGeoFactory' library public.PlaceLib;

