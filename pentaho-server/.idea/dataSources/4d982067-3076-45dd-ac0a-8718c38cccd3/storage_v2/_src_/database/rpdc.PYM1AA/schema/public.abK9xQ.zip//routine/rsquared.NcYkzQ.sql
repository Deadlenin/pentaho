create transform function rsquared as
    language 'C++'
    name 'RSQFactory' library public.MachineLearningLib;

