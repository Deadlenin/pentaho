create transform function store_robust_zscore_model as
    language 'C++'
    name 'StoreRobustZscoreModelFactory' library public.MachineLearningLib;

