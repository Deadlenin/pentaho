create transform function line_search_logistic2 as
    language 'C++'
    name 'LineSearchLogistic2Factory' library public.MachineLearningLib;

