create transform function MapKeys as
    language 'C++'
    name 'MapBinKeysFactory' library public.FlexTableLib;

