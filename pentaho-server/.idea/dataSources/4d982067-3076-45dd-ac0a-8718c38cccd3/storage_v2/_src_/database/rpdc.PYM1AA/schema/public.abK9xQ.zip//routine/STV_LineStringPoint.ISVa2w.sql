create transform function STV_LineStringPoint as
    language 'C++'
    name 'LineStringPointGeoFactory' library public.PlaceLib;

