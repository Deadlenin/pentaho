create view database_backups_mon as
SELECT database_backups.backup_timestamp,
       database_backups.node_name,
       database_backups.snapshot_name,
       database_backups.backup_epoch,
       database_backups.node_count,
       database_backups.file_system_type,
       database_backups.objects
FROM v_monitor.database_backups;

