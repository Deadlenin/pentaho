create view cvpp_date as
SELECT cvpp.report_date
FROM cvpp_new.cvpp
GROUP BY cvpp.report_date;

