create filter KafkaInsertLengths as
    language 'C++'
    name 'KafkaInsertLengthsFactory' library public.KafkaLib;

