create transform function s3export_partition as
    language 'C++'
    name 'S3ExportPartitionFactory' library public.awslib;

