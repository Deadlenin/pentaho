create view cpu_usage_mon as
SELECT cpu_usage.node_name, cpu_usage.start_time, cpu_usage.end_time, cpu_usage.average_cpu_usage_percent
FROM v_monitor.cpu_usage;

