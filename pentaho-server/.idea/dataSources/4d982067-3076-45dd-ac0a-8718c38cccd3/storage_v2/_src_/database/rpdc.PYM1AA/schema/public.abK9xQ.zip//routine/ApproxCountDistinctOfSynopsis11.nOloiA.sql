create aggregate function ApproxCountDistinctOfSynopsis11 as
    language 'C++'
    name 'ApproxCountDistinctOfSynopsis11Factory' library public.ApproximateLib;

