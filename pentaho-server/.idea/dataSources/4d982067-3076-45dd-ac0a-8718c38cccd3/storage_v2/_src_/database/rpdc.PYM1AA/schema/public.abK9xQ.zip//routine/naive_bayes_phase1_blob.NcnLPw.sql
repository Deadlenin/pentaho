create transform function naive_bayes_phase1_blob as
    language 'C++'
    name 'NaiveBayesPhase1BlobFactory' library public.MachineLearningLib;

