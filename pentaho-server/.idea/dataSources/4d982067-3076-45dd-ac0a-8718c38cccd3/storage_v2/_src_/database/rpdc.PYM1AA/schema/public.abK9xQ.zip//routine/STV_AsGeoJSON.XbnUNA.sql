create function STV_AsGeoJSON as
    language 'C++'
    name 'AsGeoJSONGeoFactory' library public.PlaceLib;

