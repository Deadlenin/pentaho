create transform function evaluate_reg_model as
    language 'C++'
    name 'EvaluateRegModelFactory' library public.MachineLearningLib;

