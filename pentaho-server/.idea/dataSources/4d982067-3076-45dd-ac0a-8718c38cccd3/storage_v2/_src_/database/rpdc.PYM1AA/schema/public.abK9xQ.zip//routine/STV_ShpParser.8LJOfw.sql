create parser STV_ShpParser as
    language 'C++'
    name 'VDParserFactory' library public.PlaceLib;

