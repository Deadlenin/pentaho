create function append_call_string_to_summary as
    language 'C++'
    name 'AppendCallStringToSummaryFactory' library public.MachineLearningLib;

