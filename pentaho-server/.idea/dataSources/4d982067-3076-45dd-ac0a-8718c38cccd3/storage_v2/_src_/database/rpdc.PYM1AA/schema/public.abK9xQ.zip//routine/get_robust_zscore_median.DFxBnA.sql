create function get_robust_zscore_median as
    language 'C++'
    name 'GetRobustZscoreMedianFactory' library public.MachineLearningLib;

