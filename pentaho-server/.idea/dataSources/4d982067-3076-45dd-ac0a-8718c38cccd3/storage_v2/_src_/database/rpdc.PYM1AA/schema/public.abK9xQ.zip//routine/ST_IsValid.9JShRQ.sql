create function ST_IsValid as
    language 'C++'
    name 'BoolNOStrFactory' library public.PlaceLib;

