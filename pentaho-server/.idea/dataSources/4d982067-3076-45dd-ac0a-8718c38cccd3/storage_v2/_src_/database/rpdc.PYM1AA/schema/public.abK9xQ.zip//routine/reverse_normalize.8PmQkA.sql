create transform function reverse_normalize as
    language 'C++'
    name 'ReverseNormalizeFactory' library public.MachineLearningLib;

