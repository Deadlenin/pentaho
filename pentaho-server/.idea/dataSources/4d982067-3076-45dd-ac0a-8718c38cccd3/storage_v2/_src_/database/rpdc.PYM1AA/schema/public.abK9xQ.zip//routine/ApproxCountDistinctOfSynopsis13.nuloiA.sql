create aggregate function ApproxCountDistinctOfSynopsis13 as
    language 'C++'
    name 'ApproxCountDistinctOfSynopsis13Factory' library public.ApproximateLib;

