create transform function compute_and_save_global_center as
    language 'C++'
    name 'AvgAllColumnsGlobalFactory' library public.MachineLearningLib;

