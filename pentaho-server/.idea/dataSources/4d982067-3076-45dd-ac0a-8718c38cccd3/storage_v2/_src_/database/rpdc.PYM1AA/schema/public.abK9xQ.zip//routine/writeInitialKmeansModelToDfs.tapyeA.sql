create transform function writeInitialKmeansModelToDfs as
    language 'C++'
    name 'WriteInitialKmeansModelToDFSFactory' library public.MachineLearningLib;

