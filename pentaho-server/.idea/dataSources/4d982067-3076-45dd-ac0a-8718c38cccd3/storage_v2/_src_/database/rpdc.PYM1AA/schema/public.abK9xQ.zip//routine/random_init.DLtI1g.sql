create transform function random_init as
    language 'C++'
    name 'RandomInitFactory' library public.MachineLearningLib;

