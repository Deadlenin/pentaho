create function ST_Centroid as
    language 'C++'
    name 'CentroidFactory' library public.PlaceLib;

