create function ST_NumGeometries as
    language 'C++'
    name 'NumGeometriesGeoFactory' library public.PlaceLib;

