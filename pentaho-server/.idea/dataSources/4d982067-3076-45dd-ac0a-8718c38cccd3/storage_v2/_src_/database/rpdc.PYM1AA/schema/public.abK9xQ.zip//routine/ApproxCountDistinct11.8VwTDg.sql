create aggregate function ApproxCountDistinct11 as
    language 'C++'
    name 'ApproxCountDistinct11Factory' library public.ApproximateLib;

