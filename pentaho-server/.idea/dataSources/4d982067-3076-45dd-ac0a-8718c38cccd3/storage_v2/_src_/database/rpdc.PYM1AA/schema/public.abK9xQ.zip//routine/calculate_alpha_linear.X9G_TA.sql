create function calculate_alpha_linear as
    language 'C++'
    name 'CalculateAlphaLinearFactory' library public.MachineLearningLib;

