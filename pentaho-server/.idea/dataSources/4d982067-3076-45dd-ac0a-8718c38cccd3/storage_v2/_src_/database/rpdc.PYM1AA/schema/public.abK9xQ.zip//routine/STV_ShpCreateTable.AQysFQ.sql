create transform function STV_ShpCreateTable as
    language 'C++'
    name 'VDCreateTableFactory' library public.PlaceLib;

