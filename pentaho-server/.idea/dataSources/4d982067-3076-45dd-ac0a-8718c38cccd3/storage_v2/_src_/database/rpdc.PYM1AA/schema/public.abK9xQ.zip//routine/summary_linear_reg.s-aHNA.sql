create function summary_linear_reg as
    language 'C++'
    name 'SummaryLinearRegFactory' library public.MachineLearningLib;

