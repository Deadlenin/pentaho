create function ST_GeographyFromText as
    language 'C++'
    name 'GeographyFromTextFactory' library public.PlaceLib;

