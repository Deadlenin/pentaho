create aggregate function ApproxCountDistinct16 as
    language 'C++'
    name 'ApproxCountDistinct16Factory' library public.ApproximateLib;

