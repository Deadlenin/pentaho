create function ST_SymDifference as
    language 'C++'
    name 'SymDifferenceFactory' library public.PlaceLib;

