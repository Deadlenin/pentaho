create parser KafkaJSONParser as
    language 'C++'
    name 'FKafkaJSONParserFactory' library public.KafkaLib;

