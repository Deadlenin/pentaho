create source KafkaSource as
    language 'C++'
    name 'KafkaSourceFactory' library public.KafkaLib;

