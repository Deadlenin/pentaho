create transform function calculate_hessian_linear1 as
    language 'C++'
    name 'CalculateHessianLinear1Factory' library public.MachineLearningLib;

