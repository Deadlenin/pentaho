create function ST_Area as
    language 'C++'
    name 'AreaGeoFactory' library public.PlaceLib;

