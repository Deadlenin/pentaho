create function summaryNaiveBayes as
    language 'C++'
    name 'SummaryNaiveBayesFactory' library public.MachineLearningLib;

