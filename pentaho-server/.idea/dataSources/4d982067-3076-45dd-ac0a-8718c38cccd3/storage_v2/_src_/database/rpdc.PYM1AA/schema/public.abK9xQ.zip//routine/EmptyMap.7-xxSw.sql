create function EmptyMap as
    language 'C++'
    name 'EmptyMapFactory' library public.FlexTableLib;

