create transform function load_rows_into_blocks as
    language 'C++'
    name 'PrepareMLDataFactory' library public.MachineLearningLib;

