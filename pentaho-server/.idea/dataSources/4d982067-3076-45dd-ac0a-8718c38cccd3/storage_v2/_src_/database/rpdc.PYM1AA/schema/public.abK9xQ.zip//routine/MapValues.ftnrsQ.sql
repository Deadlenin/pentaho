create transform function MapValues as
    language 'C++'
    name 'MapBinValuesFactory' library public.FlexTableLib;

