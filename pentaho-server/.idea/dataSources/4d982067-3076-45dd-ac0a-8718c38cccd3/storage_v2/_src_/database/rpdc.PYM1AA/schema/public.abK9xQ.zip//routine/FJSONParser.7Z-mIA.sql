create parser FJSONParser as
    language 'C++'
    name 'FJSONParserFactory' library public.FlexTableLib;

