create transform function compute_local_withinss as
    language 'C++'
    name 'WithinSumOfSquaresLocalFactory' library public.MachineLearningLib;

