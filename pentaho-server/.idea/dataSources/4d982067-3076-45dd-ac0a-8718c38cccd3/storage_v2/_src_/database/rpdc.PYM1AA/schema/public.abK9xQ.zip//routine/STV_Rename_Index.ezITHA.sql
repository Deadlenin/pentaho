create transform function STV_Rename_Index as
    language 'C++'
    name 'RenameIndexFactory' library public.PlaceLib;

