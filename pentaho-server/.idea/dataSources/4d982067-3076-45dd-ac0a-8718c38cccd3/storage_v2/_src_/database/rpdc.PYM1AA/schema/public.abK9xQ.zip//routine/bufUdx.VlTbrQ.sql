create transform function bufUdx as
    language 'C++'
    name 'TextIdentity2Factory' library v_txtindex.logSearchLib;

