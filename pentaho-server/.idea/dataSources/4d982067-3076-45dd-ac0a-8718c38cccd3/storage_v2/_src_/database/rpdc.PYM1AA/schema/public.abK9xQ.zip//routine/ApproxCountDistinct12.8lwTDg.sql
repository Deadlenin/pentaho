create aggregate function ApproxCountDistinct12 as
    language 'C++'
    name 'ApproxCountDistinct12Factory' library public.ApproximateLib;

