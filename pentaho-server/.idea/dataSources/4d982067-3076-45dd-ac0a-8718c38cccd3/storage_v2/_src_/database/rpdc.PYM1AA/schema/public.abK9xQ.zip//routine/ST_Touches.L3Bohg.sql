create function ST_Touches as
    language 'C++'
    name 'BoolNOStrStrFactory' library public.PlaceLib;

