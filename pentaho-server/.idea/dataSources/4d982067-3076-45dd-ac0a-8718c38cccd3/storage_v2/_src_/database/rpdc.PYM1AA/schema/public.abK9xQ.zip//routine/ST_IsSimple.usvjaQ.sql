create function ST_IsSimple as
    language 'C++'
    name 'IsSimpleGeoFactory' library public.PlaceLib;

