create aggregate function ApproxCountDistinct14 as
    language 'C++'
    name 'ApproxCountDistinct14Factory' library public.ApproximateLib;

