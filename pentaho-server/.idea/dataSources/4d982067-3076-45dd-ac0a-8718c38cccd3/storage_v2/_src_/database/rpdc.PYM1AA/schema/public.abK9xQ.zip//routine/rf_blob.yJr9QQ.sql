create transform function rf_blob as
    language 'C++'
    name 'WriteRFBlobFactory' library public.MachineLearningLib;

