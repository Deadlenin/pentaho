create function summary_logistic_reg as
    language 'C++'
    name 'SummaryLogisticRegFactory' library public.MachineLearningLib;

