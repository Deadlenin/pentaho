create parser FIDXParser as
    language 'C++'
    name 'FIDXParserFactory' library public.FlexTableLib;

