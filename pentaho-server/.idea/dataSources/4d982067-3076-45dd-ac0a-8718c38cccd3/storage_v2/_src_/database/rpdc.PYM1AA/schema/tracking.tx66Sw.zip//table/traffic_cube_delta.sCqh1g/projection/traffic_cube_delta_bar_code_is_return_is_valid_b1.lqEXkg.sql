CREATE PROJECTION tracking.traffic_cube_delta_bar_code_is_return_is_valid_b1 /*+basename(traffic_cube_delta_bar_code_is_return_is_valid)*/
    (
     bar_code,
     is_return,
     is_valid
        )
    AS
        SELECT traffic_cube_delta.bar_code,
               traffic_cube_delta.is_return,
               traffic_cube_delta.is_valid
        FROM tracking.traffic_cube_delta
        ORDER BY traffic_cube_delta.is_valid,
                 traffic_cube_delta.bar_code,
                 traffic_cube_delta.is_return
    SEGMENTED BY hash(traffic_cube_delta.bar_code, traffic_cube_delta.is_return,
                      traffic_cube_delta.is_valid) ALL NODES OFFSET 1;

