create function ST_ConvexHull as
    language 'C++'
    name 'ConvexHullFactory' library public.PlaceLib;

