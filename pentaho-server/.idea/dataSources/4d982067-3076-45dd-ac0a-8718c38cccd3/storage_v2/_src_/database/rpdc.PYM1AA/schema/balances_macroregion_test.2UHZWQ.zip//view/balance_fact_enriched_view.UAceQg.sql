create view balance_fact_enriched_view as
SELECT bf.bar_code,
       bf.rpo_state,
       bf.mail_type,
       bf.mail_ctg,
       bf.trans_type,
       bf.post_mark,
       bf.direct_ctg,
       bf.inter_type,
       bf.country_to,
       bf.country_from,
       bf.mass,
       bf.sndr,
       bf.rcpn,
       bf.status_date_msk,
       bf.tmp_storage,
       bf.is_return,
       bf.is_forwarding,
       bf.is_shortage,
       bf.enter_net_date,
       bf.status_change_local,
       bf.ops_from_code,
       bf.ops_to_code,
       bf.ops_code,
       bf.country_code,
       bf.mt_name,
       bf.mt_group,
       bf.trans_name,
       bf.postmark_name,
       bf.direct_ctg_name,
       bf.inter_name,
       bf.country_to_name_ru,
       bf.country_from_name_ru,
       bf.country_name_ru,
       bf.mctg_name,
       bf.olap_ufps,
       bf.fps_ops,
       bf.fps_sort_type,
       bf.fps_post_office_report,
       bf.fps_macroregion_code,
       bf.fps_olap_macroregion,
       bf.fps_olap_ufps,
       bf.fps_olap_post_office,
       bf.fps_olap_object_border,
       bf.fps_to_ops,
       bf.fps_to_olap_macroregion,
       bf.fps_to_olap_ufps,
       bf.fps_to_olap_post_office,
       bf.fps_to_olap_object_border,
       bf.fps_from_ops,
       bf.fps_from_olap_macroregion,
       bf.fps_from_olap_ufps,
       bf.fps_from_olap_post_office,
       bf.fps_from_olap_object_border,
       bf.report_date,
       bf.online,
       bf.d_0,
       bf.d_1,
       bf.d_2,
       bf.d_3,
       bf.d_4,
       bf.d_5,
       bf.d_6,
       bf.d_7,
       bf.d_8,
       bf.d_9,
       bf.d_10,
       bf.d_11,
       bf.d_30,
       bf.fps_olap_adapted_macroregion,
       bf.fps_olap_adapted_ufps,
       bf.fps_olap_adapted_post_office,
       bf.fps_olap_adapted_object_border,
       bf.fps_to_olap_adapted_macroregion,
       bf.fps_to_olap_adapted_ufps,
       bf.fps_to_olap_adapted_post_office,
       bf.fps_to_olap_adapted_object_border,
       bf.fps_from_olap_adapted_macroregion,
       bf.fps_from_olap_adapted_ufps,
       bf.fps_from_olap_adapted_post_office,
       bf.fps_from_olap_adapted_object_border
FROM (SELECT rpo.bar_code,
             rpo.rpo_state,
             rpo.mail_type,
             rpo.mail_ctg,
             rpo.trans_type,
             rpo.post_mark,
             rpo.direct_ctg,
             rpo.inter_type,
             rpo.country_to,
             rpo.country_from,
             rpo.mass,
             rpo.sndr,
             rpo.rcpn,
             rpo.status_date_msk,
             rpo.tmp_storage,
             rpo.is_return,
             rpo.is_forwarding,
             rpo.is_shortage,
             rpo.enter_net_date,
             rpo.status_change_local,
             rpo.ops_from_code,
             rpo.ops_to_code,
             rpo.ops_code,
             rpo.country_code,
             rpo.mt_name,
             rpo.mt_group,
             rpo.trans_name,
             rpo.postmark_name,
             rpo.direct_ctg_name,
             rpo.inter_name,
             rpo.country_to_name_ru,
             rpo.country_from_name_ru,
             rpo.country_name_ru,
             rpo.mctg_name,
             hier.olap_ufps,
             fps.fps_ops,
             fps.fps_sort_type,
             hier.olap_post_office                                                                             AS fps_post_office_report,
             hier.macroregion_code                                                                             AS fps_macroregion_code,
             hier.macroregion                                                                                  AS fps_olap_macroregion,
             hier.olap_ufps                                                                                    AS fps_olap_ufps,
             hier.olap_post_office                                                                             AS fps_olap_post_office,
             hier.olap_object_border                                                                           AS fps_olap_object_border,
             fps_to.fps_to_ops,
             hier_to.macroregion                                                                               AS fps_to_olap_macroregion,
             hier_to.olap_ufps                                                                                 AS fps_to_olap_ufps,
             hier_to.olap_post_office                                                                          AS fps_to_olap_post_office,
             hier_to.olap_object_border                                                                        AS fps_to_olap_object_border,
             fps_from.fps_from_ops,
             hier_from.macroregion                                                                             AS fps_from_olap_macroregion,
             hier_from.olap_ufps                                                                               AS fps_from_olap_ufps,
             hier_from.olap_post_office                                                                        AS fps_from_olap_post_office,
             hier_from.olap_object_border                                                                      AS fps_from_olap_object_border,
             rpo.report_date,
             1                                                                                                 AS online,
             ((NOT rpo.tmp_storage) AND
              (0 = "datediff"('day'::varchar(3), rpo.status_date_msk, '2020-02-26 00:00:00'::timestamp(0))))   AS d_0,
             ((NOT rpo.tmp_storage) AND
              (1 = "datediff"('day'::varchar(3), rpo.status_date_msk, '2020-02-26 00:00:00'::timestamp(0))))   AS d_1,
             ((NOT rpo.tmp_storage) AND
              (2 = "datediff"('day'::varchar(3), rpo.status_date_msk, '2020-02-26 00:00:00'::timestamp(0))))   AS d_2,
             ((NOT rpo.tmp_storage) AND
              (3 = "datediff"('day'::varchar(3), rpo.status_date_msk, '2020-02-26 00:00:00'::timestamp(0))))   AS d_3,
             ((NOT rpo.tmp_storage) AND
              (4 = "datediff"('day'::varchar(3), rpo.status_date_msk, '2020-02-26 00:00:00'::timestamp(0))))   AS d_4,
             ((NOT rpo.tmp_storage) AND
              (5 = "datediff"('day'::varchar(3), rpo.status_date_msk, '2020-02-26 00:00:00'::timestamp(0))))   AS d_5,
             ((NOT rpo.tmp_storage) AND
              (6 = "datediff"('day'::varchar(3), rpo.status_date_msk, '2020-02-26 00:00:00'::timestamp(0))))   AS d_6,
             ((NOT rpo.tmp_storage) AND
              (7 = "datediff"('day'::varchar(3), rpo.status_date_msk, '2020-02-26 00:00:00'::timestamp(0))))   AS d_7,
             ((NOT rpo.tmp_storage) AND
              (8 = "datediff"('day'::varchar(3), rpo.status_date_msk, '2020-02-26 00:00:00'::timestamp(0))))   AS d_8,
             ((NOT rpo.tmp_storage) AND
              (9 = "datediff"('day'::varchar(3), rpo.status_date_msk, '2020-02-26 00:00:00'::timestamp(0))))   AS d_9,
             ((NOT rpo.tmp_storage) AND
              (10 = "datediff"('day'::varchar(3), rpo.status_date_msk, '2020-02-26 00:00:00'::timestamp(0))))  AS d_10,
             ((NOT rpo.tmp_storage) AND
              (11 <= "datediff"('day'::varchar(3), rpo.status_date_msk, '2020-02-26 00:00:00'::timestamp(0))) AND
              ("datediff"('day'::varchar(3), rpo.status_date_msk, '2020-02-26 00:00:00'::timestamp(0)) < 30))  AS d_11,
             ((NOT rpo.tmp_storage) AND
              (30 <= "datediff"('day'::varchar(3), rpo.status_date_msk, '2020-02-26 00:00:00'::timestamp(0)))) AS d_30,
             (('[fps].['::varchar(7) || hier.macroregion) || ']'::varchar(1))                                  AS fps_olap_adapted_macroregion,
             (((('[fps].['::varchar(7) || hier.macroregion) || '].['::varchar(3)) || hier.olap_ufps) ||
              ']'::varchar(1))                                                                                 AS fps_olap_adapted_ufps,
             (((((('[fps].['::varchar(7) || hier.macroregion) || '].['::varchar(3)) || hier.olap_ufps) ||
                '].['::varchar(3)) || hier.olap_post_office) ||
              ']'::varchar(1))                                                                                 AS fps_olap_adapted_post_office,
             (((((((('[fps].['::varchar(7) || hier.macroregion) || '].['::varchar(3)) || hier.olap_ufps) ||
                  '].['::varchar(3)) || hier.olap_post_office) || '].['::varchar(3)) || hier.olap_object_border) ||
              ']'::varchar(1))                                                                                 AS fps_olap_adapted_object_border,
             (('[fps].['::varchar(7) || hier_to.macroregion) || ']'::varchar(1))                               AS fps_to_olap_adapted_macroregion,
             (((('[fps].['::varchar(7) || hier_to.macroregion) || '].['::varchar(3)) || hier_to.olap_ufps) ||
              ']'::varchar(1))                                                                                 AS fps_to_olap_adapted_ufps,
             (((((('[fps].['::varchar(7) || hier_to.macroregion) || '].['::varchar(3)) || hier_to.olap_ufps) ||
                '].['::varchar(3)) || hier_to.olap_post_office) ||
              ']'::varchar(1))                                                                                 AS fps_to_olap_adapted_post_office,
             (((((((('[fps].['::varchar(7) || hier_to.macroregion) || '].['::varchar(3)) || hier_to.olap_ufps) ||
                  '].['::varchar(3)) || hier_to.olap_post_office) || '].['::varchar(3)) ||
               hier_to.olap_object_border) ||
              ']'::varchar(1))                                                                                 AS fps_to_olap_adapted_object_border,
             (('[fps].['::varchar(7) || hier_from.macroregion) ||
              ']'::varchar(1))                                                                                 AS fps_from_olap_adapted_macroregion,
             (((('[fps].['::varchar(7) || hier_from.macroregion) || '].['::varchar(3)) || hier_from.olap_ufps) ||
              ']'::varchar(1))                                                                                 AS fps_from_olap_adapted_ufps,
             (((((('[fps].['::varchar(7) || hier_from.macroregion) || '].['::varchar(3)) || hier_from.olap_ufps) ||
                '].['::varchar(3)) || hier_from.olap_post_office) ||
              ']'::varchar(1))                                                                                 AS fps_from_olap_adapted_post_office,
             (((((((('[fps].['::varchar(7) || hier_from.macroregion) || '].['::varchar(3)) || hier_from.olap_ufps) ||
                  '].['::varchar(3)) || hier_from.olap_post_office) || '].['::varchar(3)) ||
               hier_from.olap_object_border) ||
              ']'::varchar(1))                                                                                 AS fps_from_olap_adapted_object_border
      FROM (((((((SELECT balance_fact.bar_code,
                         balance_fact.rpo_state,
                         balance_fact.mail_type,
                         balance_fact.mail_ctg,
                         balance_fact.trans_type,
                         balance_fact.post_mark,
                         balance_fact.direct_ctg,
                         balance_fact.inter_type,
                         balance_fact.country_to,
                         balance_fact.country_from,
                         balance_fact.mass,
                         balance_fact.sndr,
                         balance_fact.rcpn,
                         balance_fact.status_date_msk,
                         balance_fact.tmp_storage,
                         balance_fact.is_return,
                         balance_fact.is_forwarding,
                         balance_fact.is_shortage,
                         balance_fact.enter_net_date,
                         balance_fact.status_change_local,
                         balance_fact.ops_from_code,
                         balance_fact.ops_to_code,
                         balance_fact.ops_code,
                         balance_fact.country_code,
                         balance_fact.mt_name,
                         balance_fact.mt_group,
                         balance_fact.trans_name,
                         balance_fact.postmark_name,
                         balance_fact.direct_ctg_name,
                         balance_fact.inter_name,
                         balance_fact.country_to_name_ru,
                         balance_fact.country_from_name_ru,
                         balance_fact.country_name_ru,
                         balance_fact.report_date,
                         balance_fact.mctg_name
                  FROM balances_macroregion_test.balance_fact) rpo JOIN (SELECT full_history_enriched.macroregion_code,
                                                                                full_history_enriched.macroregion,
                                                                                ((full_history_enriched.ufps_index || ' '::varchar(1)) ||
                                                                                 full_history_enriched.ufps)        AS olap_ufps,
                                                                                ((full_history_enriched.post_office_index || ' '::varchar(1)) ||
                                                                                 full_history_enriched.post_office) AS olap_post_office,
                                                                                ((full_history_enriched.object_border_index || ' '::varchar(1)) ||
                                                                                 full_history_enriched.border)      AS olap_object_border,
                                                                                full_history_enriched.post_object_index
                                                                         FROM balances_macroregion_test.full_history_enriched
                                                                         WHERE (full_history_enriched.DATE = '2020-10-10'::varchar(10))) hier ON ((rpo.ops_code = hier.post_object_index))) LEFT JOIN (SELECT full_history_enriched.macroregion_code,
                                                                                                                                                                                                              full_history_enriched.macroregion,
                                                                                                                                                                                                              ((full_history_enriched.ufps_index || ' '::varchar(1)) ||
                                                                                                                                                                                                               full_history_enriched.ufps)        AS olap_ufps,
                                                                                                                                                                                                              ((full_history_enriched.post_office_index || ' '::varchar(1)) ||
                                                                                                                                                                                                               full_history_enriched.post_office) AS olap_post_office,
                                                                                                                                                                                                              ((full_history_enriched.object_border_index || ' '::varchar(1)) ||
                                                                                                                                                                                                               full_history_enriched.border)      AS olap_object_border,
                                                                                                                                                                                                              full_history_enriched.post_object_index
                                                                                                                                                                                                       FROM balances_macroregion_test.full_history_enriched
                                                                                                                                                                                                       WHERE (full_history_enriched.DATE = '2020-10-10'::varchar(10))) hier_to ON ((rpo.ops_to_code = hier_to.post_object_index))) LEFT JOIN (SELECT full_history_enriched.macroregion_code,
                                                                                                                                                                                                                                                                                                                                                     full_history_enriched.macroregion,
                                                                                                                                                                                                                                                                                                                                                     ((full_history_enriched.ufps_index || ' '::varchar(1)) ||
                                                                                                                                                                                                                                                                                                                                                      full_history_enriched.ufps)        AS olap_ufps,
                                                                                                                                                                                                                                                                                                                                                     ((full_history_enriched.post_office_index || ' '::varchar(1)) ||
                                                                                                                                                                                                                                                                                                                                                      full_history_enriched.post_office) AS olap_post_office,
                                                                                                                                                                                                                                                                                                                                                     ((full_history_enriched.object_border_index || ' '::varchar(1)) ||
                                                                                                                                                                                                                                                                                                                                                      full_history_enriched.border)      AS olap_object_border,
                                                                                                                                                                                                                                                                                                                                                     full_history_enriched.post_object_index
                                                                                                                                                                                                                                                                                                                                              FROM balances_macroregion_test.full_history_enriched
                                                                                                                                                                                                                                                                                                                                              WHERE (full_history_enriched.DATE = '2020-10-10'::varchar(10))) hier_from ON ((rpo.ops_from_code = hier_from.post_object_index))) JOIN (SELECT ((dim_fps_structure.post_object_index || ' '::varchar(1)) ||
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              dim_fps_structure.post_object) AS fps_ops,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             dim_fps_structure.sort_type     AS fps_sort_type,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             dim_fps_structure.post_object_index
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      FROM dicts.dim_fps_structure) fps ON ((rpo.ops_code = fps.post_object_index))) LEFT JOIN (SELECT ((dim_fps_structure.post_object_index || ' '::varchar(1)) ||
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        dim_fps_structure.post_object) AS fps_to_ops,
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       dim_fps_structure.post_object_index
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                FROM dicts.dim_fps_structure) fps_to ON ((rpo.ops_to_code = fps_to.post_object_index)))
               LEFT JOIN (SELECT ((dim_fps_structure.post_object_index || ' '::varchar(1)) ||
                                  dim_fps_structure.post_object) AS fps_from_ops,
                                 dim_fps_structure.post_object_index
                          FROM dicts.dim_fps_structure) fps_from
                         ON ((rpo.ops_from_code = fps_from.post_object_index)))) bf;

