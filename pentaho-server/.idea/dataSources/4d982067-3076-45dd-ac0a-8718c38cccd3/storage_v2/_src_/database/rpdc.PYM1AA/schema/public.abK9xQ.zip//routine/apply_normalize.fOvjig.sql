create transform function apply_normalize as
    language 'C++'
    name 'ApplyNormalizeFactory' library public.MachineLearningLib;

