create view balance_fact_dates as
SELECT balance_fact.report_date
FROM balances_1053.balance_fact
GROUP BY balance_fact.report_date;

