create aggregate function ApproxCountDistinctOfSynopsis as
    language 'C++'
    name 'ApproxCountDistinctOfSynopsisFactory' library public.ApproximateLib;

