create transform function reg_final_newton as
    language 'C++'
    name 'RegFinalNewtonFactory' library public.MachineLearningLib;

