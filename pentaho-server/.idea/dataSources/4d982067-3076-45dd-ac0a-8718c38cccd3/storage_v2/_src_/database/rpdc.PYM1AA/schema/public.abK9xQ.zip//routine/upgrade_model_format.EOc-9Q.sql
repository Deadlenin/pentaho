create function upgrade_model_format as
    language 'C++'
    name 'UpgradeModelFactory' library public.MachineLearningLib;

