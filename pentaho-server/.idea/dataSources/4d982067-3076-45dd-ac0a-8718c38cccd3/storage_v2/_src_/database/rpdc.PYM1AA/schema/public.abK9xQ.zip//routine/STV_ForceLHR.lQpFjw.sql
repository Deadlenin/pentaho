create function STV_ForceLHR as
    language 'C++'
    name 'ForceLHRFactory' library public.PlaceLib;

