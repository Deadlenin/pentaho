create function ST_intersects as
    language 'C++'
    name 'BoolNOStrStrFactory' library public.PlaceLib;

