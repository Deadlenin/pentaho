create view ends_full as
SELECT ends.rpoid,
       ends.mail_type,
       ends.mail_ctg,
       ends.send_ctg,
       ends.inn,
       ends.kpp,
       ends.a_date,
       ends.a_date_local,
       ends.a_index,
       ends.d_date,
       ends.d_index,
       ends.delivery_time,
       ends.delivery_deadline,
       ends.delivery_term,
       ends.state,
       ends.mass,
       ends.mail_type_name,
       ends.srm,
       ends.dti,
       ends.cpacket,
       ends.from_500_plus,
       ends.to_500_plus,
       ends.direction,
       ends.route,
       ends.route_po,
       ends.route_ufps,
       ends.date,
       CASE ends.state
           WHEN 'shiping_in_time'::varchar(15) THEN 'В пути без опоздания'::varchar(37)
           WHEN 'shiping_late'::varchar(12) THEN 'В пути с опозданием'::varchar(35)
           WHEN 'delivered_in_time'::varchar(17) THEN 'Доставлено вовремя'::varchar(35)
           WHEN 'not_delivered_in_time'::varchar(21) THEN 'Не доставлено вовремя'::varchar(40)
           WHEN 'unknown_delivery_term'::varchar(21) THEN 'Контрольный срок неизвестен'::varchar(52)
           WHEN 'unknown_index_to'::varchar(16)
               THEN 'Индекс места назначения не задан или отсутствует в справочниках'::varchar(118)
           WHEN 'unknown_calc_code'::varchar(17) THEN 'Вид отправления не задан в алгоритмах расчета КС'::varchar(89)
           ELSE ''::varchar END AS state_rus,
       fps_a.country_code       AS a_fps_country_code,
       fps_a.macroregion_code   AS a_fps_macroregion_code,
       fps_a.ufps_index         AS a_fps_ufps_index,
       fps_a.ufps               AS a_fps_ufps,
       fps_a.post_office_index  AS a_fps_post_office_index,
       fps_a.post_office        AS a_fps_post_office,
       fps_a.post_object        AS a_fps_post_object,
       ends.display_from_name,
       fps_a.place              AS a_place,
       fps_d.country_code       AS d_fps_country_code,
       fps_d.macroregion_code   AS d_fps_macroregion_code,
       fps_d.ufps_index         AS d_fps_ufps_index,
       fps_d.ufps               AS d_fps_ufps,
       fps_d.post_office_index  AS d_fps_post_office_index,
       fps_d.post_office        AS d_fps_post_office,
       fps_d.post_object        AS d_fps_post_object,
       fps_d.place              AS d_place
FROM ((tracking.ends_full_base ends LEFT JOIN dicts.fps_structure_full fps_a ON (((fps_a.post_object_index)::varchar = ends.a_index)))
         LEFT JOIN dicts.fps_structure_full fps_d ON (((fps_d.post_object_index)::varchar = ends.d_index)));

