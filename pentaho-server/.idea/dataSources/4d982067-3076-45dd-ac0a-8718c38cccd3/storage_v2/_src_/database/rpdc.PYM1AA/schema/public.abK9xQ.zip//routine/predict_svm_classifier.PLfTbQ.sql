create function predict_svm_classifier as
    language 'C++'
    name 'PredictSvmClassifierFactory' library public.MachineLearningLib;

