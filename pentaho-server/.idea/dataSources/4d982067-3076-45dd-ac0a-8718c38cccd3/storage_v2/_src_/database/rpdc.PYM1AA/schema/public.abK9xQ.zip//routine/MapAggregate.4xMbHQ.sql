create transform function MapAggregate as
    language 'C++'
    name 'MapLongAggregateFactory' library public.FlexTableLib;

