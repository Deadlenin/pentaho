create transform function STV_PolygonPoint as
    language 'C++'
    name 'PolygonPointGeoFactory' library public.PlaceLib;

