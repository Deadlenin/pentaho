create function get_model_summary as
    language 'C++'
    name 'SummarizeModelFactory' library public.MachineLearningLib;

