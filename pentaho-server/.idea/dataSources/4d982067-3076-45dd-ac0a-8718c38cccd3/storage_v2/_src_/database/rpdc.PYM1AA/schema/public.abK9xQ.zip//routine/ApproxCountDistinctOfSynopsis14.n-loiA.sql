create aggregate function ApproxCountDistinctOfSynopsis14 as
    language 'C++'
    name 'ApproxCountDistinctOfSynopsis14Factory' library public.ApproximateLib;

