create function summaryKmeans as
    language 'C++'
    name 'SummaryKmeansFactory' library public.MachineLearningLib;

