create transform function avg_all_columns_local as
    language 'C++'
    name 'AvgAllColumnsLocalFactory' library public.MachineLearningLib;

