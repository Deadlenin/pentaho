create function read_model_summary_from_file as
    language 'C++'
    name 'ReadModelSummaryFromFileFactory' library public.MachineLearningLib;

