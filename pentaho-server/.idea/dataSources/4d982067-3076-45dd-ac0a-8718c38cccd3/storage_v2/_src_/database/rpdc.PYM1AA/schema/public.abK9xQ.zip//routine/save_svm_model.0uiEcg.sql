create transform function save_svm_model as
    language 'C++'
    name 'SaveSvmModelFactory' library public.MachineLearningLib;

