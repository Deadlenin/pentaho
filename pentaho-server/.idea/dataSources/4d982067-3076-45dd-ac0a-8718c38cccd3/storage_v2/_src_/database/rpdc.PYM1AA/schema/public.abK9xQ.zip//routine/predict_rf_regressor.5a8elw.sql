create function predict_rf_regressor as
    language 'C++'
    name 'PredictRFRegressorFactory' library public.MachineLearningLib;

