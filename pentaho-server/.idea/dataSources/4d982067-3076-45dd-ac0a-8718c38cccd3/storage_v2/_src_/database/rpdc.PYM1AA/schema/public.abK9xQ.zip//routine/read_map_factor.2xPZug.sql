create function read_map_factor as
    language 'C++'
    name 'ReadMapFactorsFactory' library public.MachineLearningLib;

