create function ST_XMax as
    language 'C++'
    name 'XMaxGeoFactory' library public.PlaceLib;

