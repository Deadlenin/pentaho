create function ST_NumPoints as
    language 'C++'
    name 'NumPointsGeoFactory' library public.PlaceLib;

