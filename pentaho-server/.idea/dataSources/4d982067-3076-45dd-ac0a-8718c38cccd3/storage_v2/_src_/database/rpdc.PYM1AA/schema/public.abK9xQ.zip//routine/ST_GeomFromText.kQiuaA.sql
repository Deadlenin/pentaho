create function ST_GeomFromText as
    language 'C++'
    name 'GeomFromText1ArgFactory' library public.PlaceLib;

