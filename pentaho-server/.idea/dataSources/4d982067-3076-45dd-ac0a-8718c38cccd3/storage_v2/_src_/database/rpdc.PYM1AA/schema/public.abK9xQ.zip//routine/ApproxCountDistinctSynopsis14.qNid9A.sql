create aggregate function ApproxCountDistinctSynopsis14 as
    language 'C++'
    name 'ApproxCountDistinctSynopsis14Factory' library public.ApproximateLib;

