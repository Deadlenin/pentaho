create function ST_Disjoint as
    language 'C++'
    name 'BoolNOStrStrFactory' library public.PlaceLib;

