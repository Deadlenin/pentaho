create aggregate function ApproxCountDistinctSynopsis11 as
    language 'C++'
    name 'ApproxCountDistinctSynopsis11Factory' library public.ApproximateLib;

