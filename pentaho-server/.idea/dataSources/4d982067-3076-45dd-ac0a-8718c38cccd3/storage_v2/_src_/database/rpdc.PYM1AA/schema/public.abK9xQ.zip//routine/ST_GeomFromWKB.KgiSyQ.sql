create function ST_GeomFromWKB as
    language 'C++'
    name 'GeomFromWKB1ArgFactory' library public.PlaceLib;

