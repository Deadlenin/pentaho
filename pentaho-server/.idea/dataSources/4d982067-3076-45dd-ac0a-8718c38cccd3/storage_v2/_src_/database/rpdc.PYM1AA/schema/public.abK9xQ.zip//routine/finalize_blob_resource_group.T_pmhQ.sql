create transform function finalize_blob_resource_group as
    language 'C++'
    name 'FinalizeBlobResourceGroupFactory' library public.MachineLearningLib;

