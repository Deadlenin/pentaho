create function MapSize as
    language 'C++'
    name 'MapBinSizeFactory' library public.FlexTableLib;

