create function ST_Length as
    language 'C++'
    name 'LengthGeoFactory' library public.PlaceLib;

