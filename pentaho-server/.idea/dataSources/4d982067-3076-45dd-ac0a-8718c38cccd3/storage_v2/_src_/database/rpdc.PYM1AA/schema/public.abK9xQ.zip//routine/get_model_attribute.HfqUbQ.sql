create transform function get_model_attribute as
    language 'C++'
    name 'GetModelAttributeFactory' library public.MachineLearningLib;

