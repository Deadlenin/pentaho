create transform function KafkaExport as
    language 'C++'
    name 'KafkaExportFactory' library public.KafkaLib;

