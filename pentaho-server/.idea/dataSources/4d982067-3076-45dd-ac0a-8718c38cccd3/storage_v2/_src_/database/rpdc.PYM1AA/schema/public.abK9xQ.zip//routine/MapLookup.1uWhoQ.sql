create function MapLookup as
    language 'C++'
    name 'MapLookupNestedFactory' library public.FlexTableLib;

