create transform function store_minmax_model as
    language 'C++'
    name 'StoreMinMaxModelFactory' library public.MachineLearningLib;

