create function reg_write_model as
    language 'C++'
    name 'RegWriteModelFactory' library public.MachineLearningLib;

