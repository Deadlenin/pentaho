create function ST_Intersects as
    language 'C++'
    name 'IntersectsGeoFactory' library public.PlaceLib;

