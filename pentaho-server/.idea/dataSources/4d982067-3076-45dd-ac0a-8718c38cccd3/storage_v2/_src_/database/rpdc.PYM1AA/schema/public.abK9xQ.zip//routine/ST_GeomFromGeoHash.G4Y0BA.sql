create function ST_GeomFromGeoHash as
    language 'C++'
    name 'GeomFromGeoHash' library public.PlaceLib;

