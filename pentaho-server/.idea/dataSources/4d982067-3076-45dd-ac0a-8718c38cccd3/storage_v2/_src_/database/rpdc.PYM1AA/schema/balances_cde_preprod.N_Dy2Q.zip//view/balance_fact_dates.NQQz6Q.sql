create view balance_fact_dates as
SELECT balance_fact.report_date
FROM balances_cde_preprod.balance_fact
GROUP BY balance_fact.report_date;

