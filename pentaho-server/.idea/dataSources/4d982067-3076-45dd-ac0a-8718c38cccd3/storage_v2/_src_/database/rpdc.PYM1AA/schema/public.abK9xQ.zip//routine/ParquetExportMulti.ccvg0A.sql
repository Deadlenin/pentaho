create transform function ParquetExportMulti as
    language 'C++'
    name 'ParquetExportMultiFactory' library public.ParquetExportLib;

