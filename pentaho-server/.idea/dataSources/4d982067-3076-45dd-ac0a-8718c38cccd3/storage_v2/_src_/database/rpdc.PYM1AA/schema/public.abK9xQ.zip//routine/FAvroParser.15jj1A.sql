create parser FAvroParser as
    language 'C++'
    name 'FAvroParserFactory' library public.FlexTableLib;

