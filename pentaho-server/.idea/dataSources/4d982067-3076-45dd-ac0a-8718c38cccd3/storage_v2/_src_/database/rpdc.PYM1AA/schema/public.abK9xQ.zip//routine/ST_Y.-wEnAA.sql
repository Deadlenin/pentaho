create function ST_Y as
    language 'C++'
    name 'YGeoFactory' library public.PlaceLib;

