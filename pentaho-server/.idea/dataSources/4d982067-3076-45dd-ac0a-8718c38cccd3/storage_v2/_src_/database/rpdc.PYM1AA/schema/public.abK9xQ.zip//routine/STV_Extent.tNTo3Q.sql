create transform function STV_Extent as
    language 'C++'
    name 'ExtentNOStrFactory' library public.PlaceLib;

