create transform function predict_rf_classifier_classes as
    language 'C++'
    name 'PredictRFClassesFactory' library public.MachineLearningLib;

