create transform function confusion_matrix as
    language 'C++'
    name 'ConfusionMatrixFactory' library public.MachineLearningLib;

