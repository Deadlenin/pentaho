create function aws_set_config as
    language 'C++'
    name 'AwsSetConfigFactory' library public.awslib;

