create transform function KafkaOffsets as
    language 'C++'
    name 'KafkaOffsetsFactory' library public.KafkaLib;

