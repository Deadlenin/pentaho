create function MapContainsValue as
    language 'C++'
    name 'MapBinContainsValueFactory' library public.FlexTableLib;

