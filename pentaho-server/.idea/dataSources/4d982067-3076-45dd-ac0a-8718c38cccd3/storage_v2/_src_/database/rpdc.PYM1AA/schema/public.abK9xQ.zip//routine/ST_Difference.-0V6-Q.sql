create function ST_Difference as
    language 'C++'
    name 'DifferenceFactory' library public.PlaceLib;

