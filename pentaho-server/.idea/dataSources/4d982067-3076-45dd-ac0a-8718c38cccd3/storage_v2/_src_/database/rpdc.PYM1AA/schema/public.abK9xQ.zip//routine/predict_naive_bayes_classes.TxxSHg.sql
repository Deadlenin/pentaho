create transform function predict_naive_bayes_classes as
    language 'C++'
    name 'PredictNaiveBayesClassesFactory' library public.MachineLearningLib;

