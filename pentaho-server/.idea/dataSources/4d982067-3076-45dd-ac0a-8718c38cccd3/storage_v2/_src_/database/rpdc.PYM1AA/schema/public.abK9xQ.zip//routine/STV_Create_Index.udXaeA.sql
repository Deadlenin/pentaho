create transform function STV_Create_Index as
    language 'C++'
    name 'MPCreateIndexGeoFactory' library public.PlaceLib;

