create function get_hadoop_info as
    language 'JAVA'
    name 'com.vertica.hcatalogudl.WebHCatConfLoaderFactory' library public.VHCatalogLib;

