create aggregate function ApproxCountDistinctOfSynopsis16 as
    language 'C++'
    name 'ApproxCountDistinctOfSynopsis16Factory' library public.ApproximateLib;

