create aggregate function APPROXIMATE_MEDIAN as
    language 'C++'
    name 'ApproxMedianFactory' library public.ApproximateLib;

