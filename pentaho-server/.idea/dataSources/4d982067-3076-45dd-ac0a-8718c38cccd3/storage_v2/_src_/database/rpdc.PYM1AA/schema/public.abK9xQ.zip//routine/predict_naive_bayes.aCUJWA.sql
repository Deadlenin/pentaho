create function predict_naive_bayes as
    language 'C++'
    name 'PredictNaiveBayesFactory' library public.MachineLearningLib;

