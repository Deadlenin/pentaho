create function ST_GeoHash as
    language 'C++'
    name 'StrNOStrFactory' library public.PlaceLib;

