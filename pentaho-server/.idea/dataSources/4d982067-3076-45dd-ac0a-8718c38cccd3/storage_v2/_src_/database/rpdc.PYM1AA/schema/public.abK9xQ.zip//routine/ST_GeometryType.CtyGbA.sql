create function ST_GeometryType as
    language 'C++'
    name 'UDxGeometryTypeGeoFactory' library public.PlaceLib;

