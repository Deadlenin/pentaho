create transform function naive_bayes_phase1 as
    language 'C++'
    name 'NaiveBayesPhase1Factory' library public.MachineLearningLib;

