create function ST_Equals as
    language 'C++'
    name 'EqualsGeoFactory' library public.PlaceLib;

