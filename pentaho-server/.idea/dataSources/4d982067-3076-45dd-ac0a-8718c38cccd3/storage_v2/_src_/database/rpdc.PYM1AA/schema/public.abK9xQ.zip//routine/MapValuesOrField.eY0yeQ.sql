create transform function MapValuesOrField as
    language 'C++'
    name 'MapValuesOrFieldFactory' library public.FlexTableLib;

