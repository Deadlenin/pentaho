create function ST_X as
    language 'C++'
    name 'XGeoFactory' library public.PlaceLib;

