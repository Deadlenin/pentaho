create parser VHCatParser as
    language 'JAVA'
    name 'com.vertica.hcatalogudl.HCatalogSplitsParserFactory' library public.VHCatalogLib;

