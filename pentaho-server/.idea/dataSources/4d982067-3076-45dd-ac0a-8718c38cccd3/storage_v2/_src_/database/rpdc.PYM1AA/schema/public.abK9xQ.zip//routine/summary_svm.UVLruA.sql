create function summary_svm as
    language 'C++'
    name 'SummarySvmFactory' library public.MachineLearningLib;

