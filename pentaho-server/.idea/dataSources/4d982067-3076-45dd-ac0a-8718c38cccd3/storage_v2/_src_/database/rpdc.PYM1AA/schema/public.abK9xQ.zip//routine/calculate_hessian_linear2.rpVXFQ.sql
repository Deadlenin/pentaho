create transform function calculate_hessian_linear2 as
    language 'C++'
    name 'CalculateHessianLinear2Factory' library public.MachineLearningLib;

