create transform function store_one_hot_encoder_model as
    language 'C++'
    name 'StoreOneHotEncoderModelFactory' library public.MachineLearningLib;

