create function ST_XMin as
    language 'C++'
    name 'XMinGeoFactory' library public.PlaceLib;

