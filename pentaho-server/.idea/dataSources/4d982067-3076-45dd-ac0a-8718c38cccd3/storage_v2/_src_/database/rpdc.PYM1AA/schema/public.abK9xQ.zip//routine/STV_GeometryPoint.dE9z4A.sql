create function STV_GeometryPoint as
    language 'C++'
    name 'MakePoint3arg' library public.PlaceLib;

