create function predict_logistic_reg as
    language 'C++'
    name 'PredictLogisticRegFactory' library public.MachineLearningLib;

