create function ST_YMax as
    language 'C++'
    name 'YMaxGeoFactory' library public.PlaceLib;

