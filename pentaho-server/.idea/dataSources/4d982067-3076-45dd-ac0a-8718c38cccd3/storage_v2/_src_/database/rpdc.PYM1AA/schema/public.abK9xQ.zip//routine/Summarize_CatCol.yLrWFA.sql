create transform function Summarize_CatCol as
    language 'C++'
    name 'VarcharColSummarizerFactory' library public.MachineLearningLib;

