create transform function map_factor as
    language 'C++'
    name 'StoreMapFactorsFactory' library public.MachineLearningLib;

