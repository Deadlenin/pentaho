create source s3 as
    language 'C++'
    name 'S3SourceFactory' library public.awslib;

