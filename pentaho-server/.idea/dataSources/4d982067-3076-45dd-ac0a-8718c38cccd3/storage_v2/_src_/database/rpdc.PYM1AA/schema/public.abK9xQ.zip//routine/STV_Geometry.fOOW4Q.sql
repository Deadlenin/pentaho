create function STV_Geometry as
    language 'C++'
    name 'GeomNOStrFactory' library public.PlaceLib;

