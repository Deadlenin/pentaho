create function rf_clean as
    language 'C++'
    name 'RFCleanFactory' library public.MachineLearningLib;

