create function MapContainsKey as
    language 'C++'
    name 'MapBinContainsKeyFactory' library public.FlexTableLib;

