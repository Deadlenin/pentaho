create transform function compute_local_totss as
    language 'C++'
    name 'TotalSumOfSquaresLocalFactory' library public.MachineLearningLib;

