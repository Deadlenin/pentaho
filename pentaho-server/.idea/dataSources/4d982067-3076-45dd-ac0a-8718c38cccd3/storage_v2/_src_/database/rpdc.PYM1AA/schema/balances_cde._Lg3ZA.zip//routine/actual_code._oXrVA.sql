create function actual_code(current_rpo_state Integer, current_code Integer, old_code Integer) return Integer as
begin
    RETURN CASE
               WHEN (current_rpo_state <> (-1)) THEN current_code
               WHEN ((current_rpo_state = (-1)) AND (current_code = old_code)) THEN old_code
               ELSE NULL::int END;
end;

