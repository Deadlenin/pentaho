create transform function read_from_dfblob as
    language 'C++'
    name 'ReadFromDFBlobFactory' library public.MachineLearningLib;

