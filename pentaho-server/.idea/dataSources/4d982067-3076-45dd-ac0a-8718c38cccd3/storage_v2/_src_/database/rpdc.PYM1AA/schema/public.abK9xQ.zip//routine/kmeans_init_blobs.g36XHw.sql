create transform function kmeans_init_blobs as
    language 'C++'
    name 'KmeansInitBlobsFactory' library public.MachineLearningLib;

