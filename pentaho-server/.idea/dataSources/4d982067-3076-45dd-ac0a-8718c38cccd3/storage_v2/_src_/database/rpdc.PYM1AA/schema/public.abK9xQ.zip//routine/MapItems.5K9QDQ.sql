create transform function MapItems as
    language 'C++'
    name 'MapBinItemsFactory' library public.FlexTableLib;

