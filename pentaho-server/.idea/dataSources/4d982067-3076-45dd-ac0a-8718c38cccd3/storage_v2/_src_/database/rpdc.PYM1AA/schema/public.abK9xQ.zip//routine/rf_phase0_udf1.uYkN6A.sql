create transform function rf_phase0_udf1 as
    language 'C++'
    name 'RFPhase0UDF1Factory' library public.MachineLearningLib;

