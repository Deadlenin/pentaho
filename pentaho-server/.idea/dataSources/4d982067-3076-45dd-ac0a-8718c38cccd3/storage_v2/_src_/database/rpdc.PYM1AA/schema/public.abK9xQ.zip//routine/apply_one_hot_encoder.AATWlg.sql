create transform function apply_one_hot_encoder as
    language 'C++'
    name 'ApplyOneHotEncoderFactory' library public.MachineLearningLib;

