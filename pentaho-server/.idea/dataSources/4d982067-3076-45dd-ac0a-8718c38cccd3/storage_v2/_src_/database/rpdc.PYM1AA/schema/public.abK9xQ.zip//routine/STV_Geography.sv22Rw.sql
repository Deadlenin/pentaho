create function STV_Geography as
    language 'C++'
    name 'GeogNOStrFactory' library public.PlaceLib;

