create transform function append_centers as
    language 'C++'
    name 'AppendCentersFactory' library public.MachineLearningLib;

