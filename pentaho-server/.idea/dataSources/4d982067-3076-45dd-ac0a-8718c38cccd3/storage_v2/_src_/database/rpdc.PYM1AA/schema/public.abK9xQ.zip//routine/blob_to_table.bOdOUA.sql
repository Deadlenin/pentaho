create transform function blob_to_table as
    language 'C++'
    name 'BlobToTableFactory' library public.MachineLearningLib;

