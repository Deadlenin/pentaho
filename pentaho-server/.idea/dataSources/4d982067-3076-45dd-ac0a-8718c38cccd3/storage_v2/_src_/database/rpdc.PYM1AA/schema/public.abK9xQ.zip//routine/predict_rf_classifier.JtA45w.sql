create function predict_rf_classifier as
    language 'C++'
    name 'PredictRFClassifierFactory' library public.MachineLearningLib;

