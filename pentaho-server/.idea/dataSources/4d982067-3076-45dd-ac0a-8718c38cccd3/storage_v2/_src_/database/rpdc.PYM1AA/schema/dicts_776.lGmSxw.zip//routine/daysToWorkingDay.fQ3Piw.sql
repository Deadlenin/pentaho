create function daysToWorkingDay(cur_date Timestamp, wd Varchar) return Integer as
begin
    RETURN CASE
               WHEN ("substring"(wd, (date_part('isodow', cur_date))::int, 1) = 't') THEN 0
               WHEN ("substring"(wd, (date_part('isodow', (cur_date + 1)))::int, 1) = 't') THEN 1
               WHEN ("substring"(wd, (date_part('isodow', (cur_date + 2)))::int, 1) = 't') THEN 2
               WHEN ("substring"(wd, (date_part('isodow', (cur_date + 3)))::int, 1) = 't') THEN 3
               WHEN ("substring"(wd, (date_part('isodow', (cur_date + 4)))::int, 1) = 't') THEN 4
               WHEN ("substring"(wd, (date_part('isodow', (cur_date + 5)))::int, 1) = 't') THEN 5
               WHEN ("substring"(wd, (date_part('isodow', (cur_date + 6)))::int, 1) = 't') THEN 6
               ELSE NULL::int END;
end;

