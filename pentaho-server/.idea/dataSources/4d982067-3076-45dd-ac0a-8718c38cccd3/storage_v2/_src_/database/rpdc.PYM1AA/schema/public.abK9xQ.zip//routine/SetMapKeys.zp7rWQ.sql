create function SetMapKeys as
    language 'C++'
    name 'SetMapKeysFactory' library public.FlexTableLib;

