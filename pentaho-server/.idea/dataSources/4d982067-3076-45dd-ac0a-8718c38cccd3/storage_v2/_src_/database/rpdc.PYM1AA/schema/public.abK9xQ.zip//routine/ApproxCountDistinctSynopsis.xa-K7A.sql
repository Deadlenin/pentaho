create aggregate function ApproxCountDistinctSynopsis as
    language 'C++'
    name 'ApproxCountDistinctSynopsisFactory' library public.ApproximateLib;

