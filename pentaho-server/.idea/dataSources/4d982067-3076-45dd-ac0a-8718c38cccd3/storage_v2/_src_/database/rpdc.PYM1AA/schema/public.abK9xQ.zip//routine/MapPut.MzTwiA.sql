create function MapPut as
    language 'C++'
    name 'MapPutFactory' library public.FlexTableLib;

