create function predict_svm_regressor as
    language 'C++'
    name 'PredictSvmRegressorFactory' library public.MachineLearningLib;

