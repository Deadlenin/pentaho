create transform function KafkaListManyTopics as
    language 'C++'
    name 'KafkaListManyTopicsFactory' library public.KafkaLib;

