create function countWorkingDays(date_from Timestamp, date_to Timestamp, wd Varchar) return Integer as
begin
    RETURN (((floor(("datediff"('dd', date_from, date_to) / 7)) * regexp_count(wd, 't', 1, '')) + ((((((CASE
                                                                                                            WHEN ((date_to >=
                                                                                                                   (date_from + (floor(("datediff"('dd', date_from, date_to) / 7)) * 7))) AND
                                                                                                                  ("substring"(wd, (date_part('isodow', date_to))::int, 1) = 't'))
                                                                                                                THEN 1
                                                                                                            ELSE 0 END +
                                                                                                        CASE
                                                                                                            WHEN (((date_to + (-1)) >=
                                                                                                                   (date_from + (floor(("datediff"('dd', date_from, date_to) / 7)) * 7))) AND
                                                                                                                  ("substring"(wd, (date_part('isodow', (date_to + (-1))))::int, 1) =
                                                                                                                   't'))
                                                                                                                THEN 1
                                                                                                            ELSE 0 END) +
                                                                                                       CASE
                                                                                                           WHEN (((date_to + (-2)) >=
                                                                                                                  (date_from + (floor(("datediff"('dd', date_from, date_to) / 7)) * 7))) AND
                                                                                                                 ("substring"(wd, (date_part('isodow', (date_to + (-2))))::int, 1) =
                                                                                                                  't'))
                                                                                                               THEN 1
                                                                                                           ELSE 0 END) +
                                                                                                      CASE
                                                                                                          WHEN (((date_to + (-3)) >=
                                                                                                                 (date_from + (floor(("datediff"('dd', date_from, date_to) / 7)) * 7))) AND
                                                                                                                ("substring"(wd, (date_part('isodow', (date_to + (-3))))::int, 1) =
                                                                                                                 't'))
                                                                                                              THEN 1
                                                                                                          ELSE 0 END) +
                                                                                                     CASE
                                                                                                         WHEN (((date_to + (-4)) >=
                                                                                                                (date_from + (floor(("datediff"('dd', date_from, date_to) / 7)) * 7))) AND
                                                                                                               ("substring"(wd, (date_part('isodow', (date_to + (-4))))::int, 1) =
                                                                                                                't'))
                                                                                                             THEN 1
                                                                                                         ELSE 0 END) +
                                                                                                    CASE
                                                                                                        WHEN (((date_to + (-5)) >=
                                                                                                               (date_from + (floor(("datediff"('dd', date_from, date_to) / 7)) * 7))) AND
                                                                                                              ("substring"(wd, (date_part('isodow', (date_to + (-5))))::int, 1) =
                                                                                                               't'))
                                                                                                            THEN 1
                                                                                                        ELSE 0 END) +
                                                                                                   CASE
                                                                                                       WHEN (((date_to + (-6)) >=
                                                                                                              (date_from + (floor(("datediff"('dd', date_from, date_to) / 7)) * 7))) AND
                                                                                                             ("substring"(wd, (date_part('isodow', (date_to + (-6))))::int, 1) =
                                                                                                              't'))
                                                                                                           THEN 1
                                                                                                       ELSE 0 END)))::int;
end;

