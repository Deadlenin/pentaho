create function rf_save_model as
    language 'C++'
    name 'RFSaveModelFactory' library public.MachineLearningLib;

