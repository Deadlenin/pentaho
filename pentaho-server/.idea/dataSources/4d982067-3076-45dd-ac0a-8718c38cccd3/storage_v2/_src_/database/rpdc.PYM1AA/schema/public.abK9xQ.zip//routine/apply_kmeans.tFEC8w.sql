create function apply_kmeans as
    language 'C++'
    name 'KmeansApplyFactory' library public.MachineLearningLib;

