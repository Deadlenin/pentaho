create parser FRegexParser as
    language 'C++'
    name 'FRegexParserFactory' library public.FlexTableLib;

