create function ST_AsText as
    language 'C++'
    name 'AsTextGeoFactory' library public.PlaceLib;

