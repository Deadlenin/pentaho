create transform function evaluate_naive_bayes_model as
    language 'C++'
    name 'EvaluateNBModelFactory' library public.MachineLearningLib;

