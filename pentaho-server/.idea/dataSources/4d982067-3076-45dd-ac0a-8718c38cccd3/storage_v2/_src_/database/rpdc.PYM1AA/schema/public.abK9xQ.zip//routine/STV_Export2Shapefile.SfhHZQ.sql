create transform function STV_Export2Shapefile as
    language 'C++'
    name 'Export2ShapefileFactory' library public.PlaceLib;

