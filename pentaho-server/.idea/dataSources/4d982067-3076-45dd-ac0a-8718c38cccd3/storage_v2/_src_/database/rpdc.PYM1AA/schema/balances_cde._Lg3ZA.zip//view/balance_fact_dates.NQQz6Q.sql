create view balance_fact_dates as
SELECT balance_fact.report_date
FROM balances_cde.balance_fact
GROUP BY balance_fact.report_date;

