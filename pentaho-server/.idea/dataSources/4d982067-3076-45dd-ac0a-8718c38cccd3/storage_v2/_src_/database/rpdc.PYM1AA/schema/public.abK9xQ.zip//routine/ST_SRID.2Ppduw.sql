create function ST_SRID as
    language 'C++'
    name 'SRIDGeoFactory' library public.PlaceLib;

