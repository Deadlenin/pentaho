create transform function error_rate as
    language 'C++'
    name 'errorRateFactory' library public.MachineLearningLib;

