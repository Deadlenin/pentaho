create function ST_Overlaps as
    language 'C++'
    name 'OverlapsFactory' library public.PlaceLib;

