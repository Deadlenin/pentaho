create function ST_Contains as
    language 'C++'
    name 'ContainsGeoFactory' library public.PlaceLib;

