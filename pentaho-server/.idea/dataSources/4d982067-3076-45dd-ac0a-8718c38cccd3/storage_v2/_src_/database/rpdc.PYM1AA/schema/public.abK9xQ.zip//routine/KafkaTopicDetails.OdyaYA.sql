create transform function KafkaTopicDetails as
    language 'C++'
    name 'KafkaTopicDetailsFactory' library public.KafkaLib;

