create function ST_GeographyFromWKB as
    language 'C++'
    name 'GeographyFromWKBFactory' library public.PlaceLib;

