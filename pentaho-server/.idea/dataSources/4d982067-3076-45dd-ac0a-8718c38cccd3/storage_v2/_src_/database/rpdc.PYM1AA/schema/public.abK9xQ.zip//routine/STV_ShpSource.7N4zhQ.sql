create source STV_ShpSource as
    language 'C++'
    name 'VDSourceFactory' library public.PlaceLib;

