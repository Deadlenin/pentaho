create filter KafkaInsertDelimiters as
    language 'C++'
    name 'KafkaInsertDelimitersFactory' library public.KafkaLib;

