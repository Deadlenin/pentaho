create transform function KafkaListTopics as
    language 'C++'
    name 'KafkaListTopicsFactory' library public.KafkaLib;

