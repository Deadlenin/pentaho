create function ST_PointN as
    language 'C++'
    name 'PointNGeoFactory' library public.PlaceLib;

