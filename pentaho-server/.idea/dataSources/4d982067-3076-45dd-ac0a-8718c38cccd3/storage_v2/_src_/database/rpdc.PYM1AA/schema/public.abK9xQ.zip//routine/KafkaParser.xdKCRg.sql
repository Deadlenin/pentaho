create parser KafkaParser as
    language 'C++'
    name 'KafkaParserFactory' library public.KafkaLib;

