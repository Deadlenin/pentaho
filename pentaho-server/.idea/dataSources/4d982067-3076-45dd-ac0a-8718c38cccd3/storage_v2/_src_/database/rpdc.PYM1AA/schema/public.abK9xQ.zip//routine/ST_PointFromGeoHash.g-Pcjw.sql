create function ST_PointFromGeoHash as
    language 'C++'
    name 'PointFromGeoHash' library public.PlaceLib;

