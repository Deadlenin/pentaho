create aggregate function ApproxCountDistinctSynopsis16 as
    language 'C++'
    name 'ApproxCountDistinctSynopsis16Factory' library public.ApproximateLib;

