create transform function MSE as
    language 'C++'
    name 'MSEFactory' library public.MachineLearningLib;

