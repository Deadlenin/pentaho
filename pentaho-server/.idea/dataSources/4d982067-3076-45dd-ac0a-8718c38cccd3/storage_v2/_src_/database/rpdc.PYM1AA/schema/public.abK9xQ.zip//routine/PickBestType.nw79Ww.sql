create function PickBestType as
    language 'C++'
    name 'PickBestTypeMergeFactory' library public.FlexTableLib;

