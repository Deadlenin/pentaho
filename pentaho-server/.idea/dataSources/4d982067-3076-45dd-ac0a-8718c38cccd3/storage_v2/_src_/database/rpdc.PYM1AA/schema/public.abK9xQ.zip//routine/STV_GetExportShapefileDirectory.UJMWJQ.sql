create function STV_GetExportShapefileDirectory as
    language 'C++'
    name 'GetShpDirFactory' library public.PlaceLib;

