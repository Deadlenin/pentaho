create transform function naive_bayes_phase2 as
    language 'C++'
    name 'NaiveBayesPhase2Factory' library public.MachineLearningLib;

