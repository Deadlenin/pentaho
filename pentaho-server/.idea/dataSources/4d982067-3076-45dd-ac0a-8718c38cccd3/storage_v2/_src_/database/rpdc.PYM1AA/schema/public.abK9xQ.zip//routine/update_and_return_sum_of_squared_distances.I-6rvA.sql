create transform function update_and_return_sum_of_squared_distances as
    language 'C++'
    name 'UpdateAndReturnSumOfSquaredDistancesFactory' library public.MachineLearningLib;

