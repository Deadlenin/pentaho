create transform function rf_phase0_udf2 as
    language 'C++'
    name 'RFPhase0UDF2Factory' library public.MachineLearningLib;

