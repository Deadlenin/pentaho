create transform function math_op as
    language 'C++'
    name 'MathOpFactory' library public.MachineLearningLib;

