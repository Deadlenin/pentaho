create transform function get_attr_zscore as
    language 'C++'
    name 'GetAttrZscoreFactory' library public.MachineLearningLib;

