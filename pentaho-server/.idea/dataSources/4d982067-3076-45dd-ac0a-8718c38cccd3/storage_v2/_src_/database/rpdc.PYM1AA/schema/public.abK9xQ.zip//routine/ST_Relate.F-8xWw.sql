create function ST_Relate as
    language 'C++'
    name 'RelateFactory' library public.PlaceLib;

