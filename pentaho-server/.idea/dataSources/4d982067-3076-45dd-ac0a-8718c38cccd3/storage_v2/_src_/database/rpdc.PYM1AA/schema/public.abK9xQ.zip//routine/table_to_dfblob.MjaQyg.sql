create transform function table_to_dfblob as
    language 'C++'
    name 'TableToDFBlobFactory' library public.MachineLearningLib;

