create transform function ParquetExport as
    language 'C++'
    name 'ParquetExportFactory' library public.ParquetExportLib;

