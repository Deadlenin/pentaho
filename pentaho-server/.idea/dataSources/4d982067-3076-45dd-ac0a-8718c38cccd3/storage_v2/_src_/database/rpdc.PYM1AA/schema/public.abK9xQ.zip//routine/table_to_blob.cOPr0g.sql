create transform function table_to_blob as
    language 'C++'
    name 'TableToBlobFactory' library public.MachineLearningLib;

