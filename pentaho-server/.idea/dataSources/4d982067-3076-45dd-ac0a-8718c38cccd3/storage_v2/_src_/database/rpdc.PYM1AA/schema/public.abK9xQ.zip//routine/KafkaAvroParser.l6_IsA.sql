create parser KafkaAvroParser as
    language 'C++'
    name 'FKafkaAvroParserFactory' library public.KafkaLib;

