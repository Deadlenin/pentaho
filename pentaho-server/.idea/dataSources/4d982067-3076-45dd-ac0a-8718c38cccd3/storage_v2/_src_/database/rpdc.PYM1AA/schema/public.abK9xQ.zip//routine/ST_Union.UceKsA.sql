create function ST_Union as
    language 'C++'
    name 'UnionFactory' library public.PlaceLib;

