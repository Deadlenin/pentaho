create transform function select_new_centers as
    language 'C++'
    name 'SelectNewCentersFactory' library public.MachineLearningLib;

