create function ST_Buffer as
    language 'C++'
    name 'BufferFactory' library public.PlaceLib;

