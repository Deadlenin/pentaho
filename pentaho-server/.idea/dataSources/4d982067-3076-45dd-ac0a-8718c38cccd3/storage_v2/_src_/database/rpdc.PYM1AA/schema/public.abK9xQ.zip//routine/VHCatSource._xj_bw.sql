create source VHCatSource as
    language 'JAVA'
    name 'com.vertica.hcatalogudl.HCatalogSplitsNoOpSourceFactory' library public.VHCatalogLib;

