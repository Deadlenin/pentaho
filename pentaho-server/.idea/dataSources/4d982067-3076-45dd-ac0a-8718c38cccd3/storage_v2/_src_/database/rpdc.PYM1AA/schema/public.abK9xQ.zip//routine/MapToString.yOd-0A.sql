create function MapToString as
    language 'C++'
    name 'MapBinToStringFactory' library public.FlexTableLib;

