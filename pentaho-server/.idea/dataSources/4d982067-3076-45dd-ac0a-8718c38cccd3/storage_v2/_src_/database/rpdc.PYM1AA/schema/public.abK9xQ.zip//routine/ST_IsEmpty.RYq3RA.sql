create function ST_IsEmpty as
    language 'C++'
    name 'IsEmptyGeoFactory' library public.PlaceLib;

