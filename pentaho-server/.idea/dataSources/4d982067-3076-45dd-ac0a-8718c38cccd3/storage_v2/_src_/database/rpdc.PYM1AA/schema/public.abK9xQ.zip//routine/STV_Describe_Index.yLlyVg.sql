create transform function STV_Describe_Index as
    language 'C++'
    name 'DescribeIndexFactory' library public.PlaceLib;

