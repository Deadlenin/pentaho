create function read_tree as
    language 'C++'
    name 'ReadTreeFactory' library public.MachineLearningLib;

