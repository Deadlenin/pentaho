create transform function kmeans_to_write_final_centers as
    language 'C++'
    name 'KmeansToWriteFinalCentersFactory' library public.MachineLearningLib;

