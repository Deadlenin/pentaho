create aggregate function ApproxCountDistinct as
    language 'C++'
    name 'ApproxCountDistinctFactory' library public.ApproximateLib;

