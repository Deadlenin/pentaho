create transform function get_attr_minmax as
    language 'C++'
    name 'GetAttrMinMaxFactory' library public.MachineLearningLib;

