create view bfact_view_hier as
SELECT rpo.bar_code,
       rpo.rpo_state,
       rpo.mail_type,
       rpo.mail_ctg,
       rpo.trans_type,
       rpo.post_mark,
       rpo.direct_ctg,
       rpo.inter_type,
       rpo.country_to,
       rpo.country_from,
       rpo.mass,
       rpo.sndr,
       rpo.rcpn,
       rpo.status_date_msk,
       rpo.tmp_storage,
       rpo.is_return,
       rpo.is_forwarding,
       rpo.is_shortage,
       rpo.enter_net_date,
       rpo.status_change_local,
       rpo.ops_from_code,
       rpo.ops_to_code,
       rpo.ops_code,
       rpo.country_code,
       rpo.mt_name,
       rpo.mt_group,
       rpo.trans_name,
       rpo.postmark_name,
       rpo.direct_ctg_name,
       rpo.inter_name,
       rpo.country_to_name_ru,
       rpo.country_from_name_ru,
       rpo.country_name_ru,
       rpo.mctg_name,
       rpo.report_date,
       rpo.online,
       ((NOT rpo.tmp_storage) AND
        (0 = "datediff"('day'::varchar(3), rpo.status_date_msk, '2020-02-26 00:00:00'::timestamp(0))))   AS d_0,
       ((NOT rpo.tmp_storage) AND
        (1 = "datediff"('day'::varchar(3), rpo.status_date_msk, '2020-02-26 00:00:00'::timestamp(0))))   AS d_1,
       ((NOT rpo.tmp_storage) AND
        (2 = "datediff"('day'::varchar(3), rpo.status_date_msk, '2020-02-26 00:00:00'::timestamp(0))))   AS d_2,
       ((NOT rpo.tmp_storage) AND
        (3 = "datediff"('day'::varchar(3), rpo.status_date_msk, '2020-02-26 00:00:00'::timestamp(0))))   AS d_3,
       ((NOT rpo.tmp_storage) AND
        (4 = "datediff"('day'::varchar(3), rpo.status_date_msk, '2020-02-26 00:00:00'::timestamp(0))))   AS d_4,
       ((NOT rpo.tmp_storage) AND
        (5 = "datediff"('day'::varchar(3), rpo.status_date_msk, '2020-02-26 00:00:00'::timestamp(0))))   AS d_5,
       ((NOT rpo.tmp_storage) AND
        (6 = "datediff"('day'::varchar(3), rpo.status_date_msk, '2020-02-26 00:00:00'::timestamp(0))))   AS d_6,
       ((NOT rpo.tmp_storage) AND
        (7 = "datediff"('day'::varchar(3), rpo.status_date_msk, '2020-02-26 00:00:00'::timestamp(0))))   AS d_7,
       ((NOT rpo.tmp_storage) AND
        (8 = "datediff"('day'::varchar(3), rpo.status_date_msk, '2020-02-26 00:00:00'::timestamp(0))))   AS d_8,
       ((NOT rpo.tmp_storage) AND
        (9 = "datediff"('day'::varchar(3), rpo.status_date_msk, '2020-02-26 00:00:00'::timestamp(0))))   AS d_9,
       ((NOT rpo.tmp_storage) AND
        (10 = "datediff"('day'::varchar(3), rpo.status_date_msk, '2020-02-26 00:00:00'::timestamp(0))))  AS d_10,
       ((NOT rpo.tmp_storage) AND
        (11 <= "datediff"('day'::varchar(3), rpo.status_date_msk, '2020-02-26 00:00:00'::timestamp(0))) AND
        ("datediff"('day'::varchar(3), rpo.status_date_msk, '2020-02-26 00:00:00'::timestamp(0)) < 30))  AS d_11,
       ((NOT rpo.tmp_storage) AND
        (30 <= "datediff"('day'::varchar(3), rpo.status_date_msk, '2020-02-26 00:00:00'::timestamp(0)))) AS d_30
FROM (SELECT balance_fact.bar_code,
             balance_fact.rpo_state,
             balance_fact.mail_type,
             balance_fact.mail_ctg,
             balance_fact.trans_type,
             balance_fact.post_mark,
             balance_fact.direct_ctg,
             balance_fact.inter_type,
             balance_fact.country_to,
             balance_fact.country_from,
             balance_fact.mass,
             balance_fact.sndr,
             balance_fact.rcpn,
             balance_fact.status_date_msk,
             balance_fact.tmp_storage,
             balance_fact.is_return,
             balance_fact.is_forwarding,
             balance_fact.is_shortage,
             balance_fact.enter_net_date,
             balance_fact.status_change_local,
             balance_fact.ops_from_code,
             balance_fact.ops_to_code,
             balance_fact.ops_code,
             balance_fact.country_code,
             balance_fact.mt_name,
             balance_fact.mt_group,
             balance_fact.trans_name,
             balance_fact.postmark_name,
             balance_fact.direct_ctg_name,
             balance_fact.inter_name,
             balance_fact.country_to_name_ru,
             balance_fact.country_from_name_ru,
             balance_fact.country_name_ru,
             balance_fact.mctg_name,
             balance_fact.report_date,
             true AS online
      FROM balances_macroregion_test.balance_fact) rpo
ORDER BY rpo.ops_code, rpo.ops_from_code, rpo.ops_to_code;

