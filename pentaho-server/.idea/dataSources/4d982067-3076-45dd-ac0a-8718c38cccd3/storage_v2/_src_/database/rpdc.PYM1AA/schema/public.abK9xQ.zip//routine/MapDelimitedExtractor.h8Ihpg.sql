create function MapDelimitedExtractor as
    language 'C++'
    name 'FDelimitedExtractorFactory' library public.FlexTableLib;

