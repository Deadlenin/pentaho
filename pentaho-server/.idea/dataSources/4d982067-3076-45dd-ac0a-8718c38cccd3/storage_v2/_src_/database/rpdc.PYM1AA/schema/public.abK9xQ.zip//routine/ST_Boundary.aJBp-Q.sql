create function ST_Boundary as
    language 'C++'
    name 'BoundaryFactory' library public.PlaceLib;

