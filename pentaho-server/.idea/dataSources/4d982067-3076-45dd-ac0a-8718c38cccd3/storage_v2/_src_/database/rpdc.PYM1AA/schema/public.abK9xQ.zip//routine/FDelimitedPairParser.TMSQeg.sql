create parser FDelimitedPairParser as
    language 'C++'
    name 'FDelimPairParserFactory' library public.FlexTableLib;

