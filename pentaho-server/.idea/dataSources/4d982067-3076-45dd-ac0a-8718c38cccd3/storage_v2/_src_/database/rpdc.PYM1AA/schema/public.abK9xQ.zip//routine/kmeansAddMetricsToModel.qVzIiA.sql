create function kmeansAddMetricsToModel as
    language 'C++'
    name 'KmeansAddMetricsToModelFactory' library public.MachineLearningLib;

