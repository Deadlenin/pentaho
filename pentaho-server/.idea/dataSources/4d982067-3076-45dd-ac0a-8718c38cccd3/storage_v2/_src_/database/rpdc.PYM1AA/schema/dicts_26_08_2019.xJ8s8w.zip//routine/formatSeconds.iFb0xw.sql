create function formatSeconds(seconds Integer) return Varchar as
begin
    RETURN ((((lpad(((seconds // 3600))::varchar, 2, '0') || ':') ||
              lpad((((seconds % 3600) // 60))::varchar, 2, '0')) || ':') ||
            lpad((((seconds % 3600) % 60))::varchar, 2, '0'));
end;

