create parser FCsvParser as
    language 'C++'
    name 'FCsvParserFactory' library public.FlexTableLib;

