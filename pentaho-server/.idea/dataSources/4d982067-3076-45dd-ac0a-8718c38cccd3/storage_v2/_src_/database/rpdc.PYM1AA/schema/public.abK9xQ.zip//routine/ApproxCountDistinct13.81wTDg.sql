create aggregate function ApproxCountDistinct13 as
    language 'C++'
    name 'ApproxCountDistinct13Factory' library public.ApproximateLib;

