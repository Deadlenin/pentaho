create transform function FlexTokenizer as
    language 'C++'
    name 'FlexTokenizerFactory' library public.FlexTableLib;

