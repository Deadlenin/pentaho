create view kpi_zone_drill_rpos as
SELECT CASE
           WHEN (kpi_zone.mail_direction = 1) THEN 'incoming'::varchar(8)
           WHEN (kpi_zone.mail_direction = 2) THEN 'outgoing'::varchar(8)
           WHEN (kpi_zone.mail_direction = 3) THEN 'in_ufps'::varchar(7)
           ELSE NULL END                                                                                              AS mail_direction,
       kpi_zone.index_src,
       kpi_zone.index_dest,
       kpi_zone.index_filter,
       kpi_zone.acc_time,
       kpi_zone.acc_term,
       kpi_zone.eow_time,
       kpi_zone.eow_term,
       kpi_zone.common_time,
       kpi_zone.common_term,
       CASE
           WHEN (kpi_zone.kpi_ctg = 0) THEN 'on_way'::varchar(6)
           WHEN (kpi_zone.kpi_ctg = 1) THEN 'in_time'::varchar(7)
           WHEN (kpi_zone.kpi_ctg = 2) THEN 'not_in_time'::varchar(11)
           ELSE NULL END                                                                                              AS kpi_ctg,
       kpi_zone.bar_code,
       kpi_zone.accepting_date,
       kpi_zone.mail_ctg,
       kpi_zone.trans_type,
       kpi_zone.any_in_time,
       kpi_zone.any_total,
       kpi_zone.incoming_not_in_time,
       kpi_zone.incoming_in_time,
       kpi_zone.incoming_on_way,
       kpi_zone.incoming_total,
       kpi_zone.outgoing_not_in_time,
       kpi_zone.outgoing_in_time,
       kpi_zone.outgoing_on_way,
       kpi_zone.outgoing_total,
       kpi_zone.in_ufps_not_in_time,
       kpi_zone.in_ufps_in_time,
       kpi_zone.in_ufps_on_way,
       kpi_zone.in_ufps_total,
       (('[fps].['::varchar(7) || kpi_zone.macroregion) || ']'::varchar(1))                                           AS macroregion_olap,
       (((('[fps].['::varchar(7) || kpi_zone.macroregion) || '].['::varchar(3)) || kpi_zone.ufps) ||
        ']'::varchar(1))                                                                                              AS ufps_olap,
       (((((('[fps].['::varchar(7) || kpi_zone.macroregion) || '].['::varchar(3)) || kpi_zone.ufps) ||
          '].['::varchar(3)) || kpi_zone.post_office) ||
        ']'::varchar(1))                                                                                              AS post_office_olap,
       (((((((('[fps].['::varchar(7) || kpi_zone.macroregion) || '].['::varchar(3)) || kpi_zone.ufps) ||
            '].['::varchar(3)) || kpi_zone.post_office) || '].['::varchar(3)) || kpi_zone.post_object) ||
        ']'::varchar(1))                                                                                              AS post_object_olap,
       kpi_zone.macroregion,
       kpi_zone.ufps_index_direction                                                                                  AS ufps_index,
       kpi_zone.ufps_direction,
       kpi_zone.ufps,
       (('[mail_type].['::varchar(13) || kpi_zone.mail_type_group) ||
        ']'::varchar(1))                                                                                              AS mail_type_group_olap,
       (((('[mail_type].['::varchar(13) || kpi_zone.mail_type_group) || '].['::varchar(3)) ||
         kpi_zone.mail_type_name) ||
        ']'::varchar(1))                                                                                              AS mail_type_name_olap,
       kpi_zone.mail_type_name,
       kpi_zone.mail_type_group
FROM tracking.kpi_zone;

