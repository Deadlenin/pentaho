create transform function store_zscore_model as
    language 'C++'
    name 'StoreZscoreModelFactory' library public.MachineLearningLib;

