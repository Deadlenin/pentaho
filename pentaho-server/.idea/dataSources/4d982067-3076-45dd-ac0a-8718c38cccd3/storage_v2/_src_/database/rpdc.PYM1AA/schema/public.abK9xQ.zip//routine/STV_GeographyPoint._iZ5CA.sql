create function STV_GeographyPoint as
    language 'C++'
    name 'MakeGeographyPoint2argFactory' library public.PlaceLib;

