create function import_model_files as
    language 'C++'
    name 'ImportModelFactory' library public.MachineLearningLib;

