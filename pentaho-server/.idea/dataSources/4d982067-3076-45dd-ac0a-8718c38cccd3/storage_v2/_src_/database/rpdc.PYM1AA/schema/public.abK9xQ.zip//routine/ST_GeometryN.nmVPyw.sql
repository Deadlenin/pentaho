create function ST_GeometryN as
    language 'C++'
    name 'GeomNOStrIntFactory' library public.PlaceLib;

