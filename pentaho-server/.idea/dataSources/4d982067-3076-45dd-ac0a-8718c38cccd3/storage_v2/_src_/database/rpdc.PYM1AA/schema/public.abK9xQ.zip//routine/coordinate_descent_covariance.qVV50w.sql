create transform function coordinate_descent_covariance as
    language 'C++'
    name 'CDCovarianceFactory' library public.MachineLearningLib;

