create function actual_place(current_rpo_state Integer, current_place Varchar, old_place Varchar) return Varchar as
begin
    RETURN CASE
               WHEN (current_rpo_state <> (-1)) THEN current_place
               WHEN ((current_rpo_state = (-1)) AND (current_place = old_place)) THEN old_place
               ELSE NULL END;
end;

