create transform function s3export as
    language 'C++'
    name 'S3ExportFactory' library public.awslib;

