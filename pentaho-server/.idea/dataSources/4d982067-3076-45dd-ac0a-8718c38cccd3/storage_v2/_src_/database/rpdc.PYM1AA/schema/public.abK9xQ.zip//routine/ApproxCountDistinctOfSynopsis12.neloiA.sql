create aggregate function ApproxCountDistinctOfSynopsis12 as
    language 'C++'
    name 'ApproxCountDistinctOfSynopsis12Factory' library public.ApproximateLib;

