create function ST_Distance as
    language 'C++'
    name 'DistanceGeoFactory' library public.PlaceLib;

