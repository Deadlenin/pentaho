create transform function compute_new_local_centers as
    language 'C++'
    name 'ComputeNewLocalCentersFactory' library public.MachineLearningLib;

