create aggregate function ApproxCountDistinctSynopsis12 as
    language 'C++'
    name 'ApproxCountDistinctSynopsis12Factory' library public.ApproximateLib;

