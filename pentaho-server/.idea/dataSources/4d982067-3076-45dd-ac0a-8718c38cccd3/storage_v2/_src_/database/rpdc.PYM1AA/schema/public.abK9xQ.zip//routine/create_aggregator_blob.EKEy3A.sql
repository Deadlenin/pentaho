create transform function create_aggregator_blob as
    language 'C++'
    name 'AggrBlobCreatorFactory' library public.MachineLearningLib;

