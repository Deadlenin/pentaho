CREATE PROJECTION dicts.dim_fps_structure_opt
    (
     region,
     place,
     post_object_index,
     post_object,
     post_object_no_index,
     object_border_type,
     sort_type
        )
    AS
        SELECT dim_fps_structure.region,
               dim_fps_structure.place,
               dim_fps_structure.post_object_index,
               dim_fps_structure.post_object,
               dim_fps_structure.post_object_no_index,
               dim_fps_structure.object_border_type,
               dim_fps_structure.sort_type
        FROM dicts.dim_fps_structure
        ORDER BY dim_fps_structure.post_object_index
    UNSEGMENTED ALL NODES;

