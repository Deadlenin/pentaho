create function ST_Intersection as
    language 'C++'
    name 'IntersectionFactory' library public.PlaceLib;

