create transform function count_rows_in_blob as
    language 'C++'
    name 'CountRowsInBlobFactory' library public.MachineLearningLib;

