create transform function get_hive_metadata as
    language 'JAVA'
    name 'com.vertica.hcatalogudl.HiveServer2ConnectorFactory' library public.VHCatalogLib;

