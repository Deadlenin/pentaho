create transform function STV_Drop_Index as
    language 'C++'
    name 'DropIndexFactory' library public.PlaceLib;

