create function ST_Crosses as
    language 'C++'
    name 'CrossesFactory' library public.PlaceLib;

