create function MapRegexExtractor as
    language 'C++'
    name 'RegexExtractorFactory' library public.FlexTableLib;

