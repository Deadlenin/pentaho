create transform function rf_phase1_udf2 as
    language 'C++'
    name 'RFPhase1UDF2Factory' library public.MachineLearningLib;

