create transform function STV_NN as
    language 'C++'
    name 'kNNFactoryGeo' library public.PlaceLib;

