create transform function random_init_write as
    language 'C++'
    name 'RandomInitWriteFactory' library public.MachineLearningLib;

