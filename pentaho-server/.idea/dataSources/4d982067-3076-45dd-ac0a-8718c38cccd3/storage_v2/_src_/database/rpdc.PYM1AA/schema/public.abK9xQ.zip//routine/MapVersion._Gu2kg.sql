create function MapVersion as
    language 'C++'
    name 'MapBinVersionFactory' library public.FlexTableLib;

