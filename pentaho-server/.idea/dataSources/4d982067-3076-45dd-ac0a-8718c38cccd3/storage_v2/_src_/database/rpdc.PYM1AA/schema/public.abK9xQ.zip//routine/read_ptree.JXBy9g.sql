create function read_ptree as
    language 'C++'
    name 'ReadPTreeFactory' library public.MachineLearningLib;

