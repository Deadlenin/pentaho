create parser FDelimitedParser as
    language 'C++'
    name 'FDelimitedParserFactory' library public.FlexTableLib;

