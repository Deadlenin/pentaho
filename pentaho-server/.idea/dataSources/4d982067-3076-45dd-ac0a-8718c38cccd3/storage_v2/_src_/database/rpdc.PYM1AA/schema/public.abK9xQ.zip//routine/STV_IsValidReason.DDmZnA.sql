create function STV_IsValidReason as
    language 'C++'
    name 'StrNOStrFactory' library public.PlaceLib;

