create transform function compute_and_save_new_centers as
    language 'C++'
    name 'ComputeAndSaveNewCentersFactory' library public.MachineLearningLib;

