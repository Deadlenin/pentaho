create transform function MapKeysInfo as
    language 'C++'
    name 'MapBinKeysInfoFactory' library public.FlexTableLib;

