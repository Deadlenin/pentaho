create function STV_SetExportShapefileDirectory as
    language 'C++'
    name 'SetShpDirFactory' library public.PlaceLib;

