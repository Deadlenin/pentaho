create transform function ParquetExportFinalize as
    language 'C++'
    name 'ParquetExportFinalizeFactory' library public.ParquetExportLib;

