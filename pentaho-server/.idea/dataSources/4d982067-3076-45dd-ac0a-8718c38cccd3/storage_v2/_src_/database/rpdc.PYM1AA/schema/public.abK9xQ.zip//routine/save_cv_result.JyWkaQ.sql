create transform function save_cv_result as
    language 'C++'
    name 'CvResultWriterFactory' library public.MachineLearningLib;

