create function predict_linear_reg as
    language 'C++'
    name 'PredictLinearRegFactory' library public.MachineLearningLib;

