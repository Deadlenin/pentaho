create function ST_Envelope as
    language 'C++'
    name 'EnvelopeFactory' library public.PlaceLib;

