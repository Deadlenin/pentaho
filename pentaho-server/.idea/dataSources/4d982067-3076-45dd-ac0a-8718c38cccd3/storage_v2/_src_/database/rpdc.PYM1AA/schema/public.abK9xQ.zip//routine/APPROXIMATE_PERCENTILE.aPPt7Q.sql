create aggregate function APPROXIMATE_PERCENTILE as
    language 'C++'
    name 'ApproxPercentileFactory' library public.ApproximateLib;

