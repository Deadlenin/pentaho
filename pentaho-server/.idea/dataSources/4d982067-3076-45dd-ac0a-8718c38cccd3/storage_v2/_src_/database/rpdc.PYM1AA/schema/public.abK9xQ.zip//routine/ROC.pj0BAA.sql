create transform function ROC as
    language 'C++'
    name 'ROCFactory' library public.MachineLearningLib;

