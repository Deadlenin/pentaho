create view active_events_mon as
SELECT active_events.node_name,
       active_events.event_code,
       active_events.event_id,
       active_events.event_severity,
       active_events.event_posted_timestamp,
       active_events.event_expiration,
       active_events.event_code_description,
       active_events.event_problem_description,
       active_events.reporting_node,
       active_events.event_sent_to_channels,
       active_events.event_posted_count
FROM v_monitor.active_events;

