create transform function lift_table as
    language 'C++'
    name 'liftTableFactory' library public.MachineLearningLib;

