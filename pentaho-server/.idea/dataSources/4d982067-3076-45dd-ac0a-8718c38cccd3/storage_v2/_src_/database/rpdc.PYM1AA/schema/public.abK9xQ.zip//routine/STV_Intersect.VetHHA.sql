create transform function STV_Intersect as
    language 'C++'
    name 'SpJoinTxyFactory' library public.PlaceLib;

