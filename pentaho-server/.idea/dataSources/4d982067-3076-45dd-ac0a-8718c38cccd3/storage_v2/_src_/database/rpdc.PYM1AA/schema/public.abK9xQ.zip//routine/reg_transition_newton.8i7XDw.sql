create transform function reg_transition_newton as
    language 'C++'
    name 'RegTransitionNewtonFactory' library public.MachineLearningLib;

