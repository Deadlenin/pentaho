create transform function STV_Refresh_Index as
    language 'C++'
    name 'MPRefreshIndexGeoFactory' library public.PlaceLib;

